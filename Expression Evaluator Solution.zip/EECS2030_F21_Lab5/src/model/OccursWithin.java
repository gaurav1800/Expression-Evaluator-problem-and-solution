package model;

public class OccursWithin extends BinarySeqOperation {

	private boolean occurs;
	private int counter;

	public OccursWithin() {
		// just initialize the default values of variables
	}

	public OccursWithin(int[] arr1, int[] arr2) {
		super(arr1, arr2);
		setResult();
	}

	public void setResult() {

		if (arr2.length < arr1.length || (arr1.length != 0 && arr2.length == 0)) {
			occurs = false;
		} 
		else if (arr1.length == 0) {
			occurs = true;
		} 
		else {

			for (int i = 0; i < arr2.length; i++) {
				if (arr2[i] == arr1[0]) {

					for (int j = 0, k = i; j < arr1.length && k < arr2.length; j++, k++) {

						if (arr1[j] == arr2[k]) {
							counter++;
						} else {
							counter = 0;
							break;
						}
					}
				}
				if (counter == arr1.length) {
					occurs = true;
					break;
				}
				else {
					occurs = false;
				}
			}
		}
	}


	public String getResultString() {
		String s;
		if (occurs) {
			s = "true";
		} else {
			s = "_";
		}
		return s;
	}

	public String toString() {
		String appendString;
		if (occurs) {
			appendString = " occurs within ";
		} else {
			appendString = " does not occur within ";
		}

		String s = getSeq1String() + appendString + getSeq2String();
		return s;
	}

}
