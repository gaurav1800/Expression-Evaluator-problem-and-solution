package model;

public abstract class BinarySeqOperation extends SeqOperation {

	protected int[] arr2;

	public BinarySeqOperation() {
		// just initialize the default values of variables
	}

	public BinarySeqOperation(int[] arr1, int[] arr2) {
		super(arr1);
		this.arr2 = arr2;
	}

	public String getSeq2String() {
		return convertArrayToStr(arr2);
	}
}
