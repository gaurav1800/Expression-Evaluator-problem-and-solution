package model;

public class IllegalOperationException extends RuntimeException{
	
	public IllegalOperationException() {
		super();
	}

}
