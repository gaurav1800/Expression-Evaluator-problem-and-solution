package model;

public class FilterAll extends SeqEvaluator{
	
	public FilterAll() {
		// just initialize the default values of variables
	}
	
	public FilterAll(int maxOps) {
		super(maxOps);
	}
	
	public void addOperation(String operation, int[] seq1, int[] seq2) {
		if (operation.equals("op:projection")) {
			projectedArray[numOfOps] = new Projection(seq1, seq2);
			numOfInvalidOperations++;
		} else if (operation.equals("op:sumsOfPrefixes")) {
			projectedArray[numOfOps] = new SumsOfPrefixes(seq1);
			numOfInvalidOperations++;
		} else if (operation.equals("op:occursWithin")) {
			projectedArray[numOfOps] = new OccursWithin(seq1, seq2);
		} else {
			throw new IllegalOperationException();
		}
		numOfOps++;
	}

	public String getConcatenatedResults() {
		String concatenatedString = "";
		for (int i = 0; i < numOfOps; i++) {
			if (i != 0) {
				concatenatedString += ", ";
			}
			concatenatedString += projectedArray[i].getResultString();
		}
		return concatenatedString;
	}

	public String toString() {
		String s;
		if (numOfInvalidOperations > 0) {
			s = "Filter cannot be evaluated due to " + numOfInvalidOperations + " incompatile operations.";
			
		} else {
			s = "Filter result is: " + getConcatenatedResults();
		}
		return s;
	}
 }
