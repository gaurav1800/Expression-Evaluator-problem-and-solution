package model;

public abstract class SeqEvaluator {

	protected SeqOperation[] projectedArray;
	protected int numOfOps;
	protected int numOfInvalidOperations;
	protected int maxOps; // max operations

	public SeqEvaluator() {
		// just initialize the default values of variables
	}

	public SeqEvaluator(int maxOps) {
		this.maxOps = maxOps;
		numOfOps = 0;
		projectedArray = new SeqOperation[maxOps];
		numOfInvalidOperations = 0;
	}

	public abstract void addOperation(String operation, int[] seq1, int[] seq2);

}
