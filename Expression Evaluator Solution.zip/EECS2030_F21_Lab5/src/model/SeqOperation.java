package model;

public abstract class SeqOperation {

	protected int[] arr1;
	protected int[] resultArray;

	public SeqOperation() {
		// just to initialize the default values of variables
	}

	public SeqOperation(int[] arr1) {
		this.arr1 = arr1;
	}

	public abstract void setResult();

	public int[] getResultArr() {
		return resultArray;
	}

	public String getResultString() {
		return convertArrayToStr(resultArray);
	}

	public String getSeq1String() {
		return convertArrayToStr(arr1);
	}

	public String convertArrayToStr(int[] arr) {
		String s = "[";

		for (int i = 0; i < arr.length; i++) {
			if (i != 0) {
				s += ", ";
			}
			s += arr[i];
		}

		s += "]";
		return s;
	}

}
