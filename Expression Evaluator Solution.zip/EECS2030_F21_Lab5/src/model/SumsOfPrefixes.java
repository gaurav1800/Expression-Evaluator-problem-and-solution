package model;

public class SumsOfPrefixes extends SeqOperation {

	public SumsOfPrefixes() {
		// just initialize the default values of variables
	}

	public SumsOfPrefixes(int[] arr1) {
		super(arr1);
		setResult();
	}

	public void setResult() {
		resultArray = new int[arr1.length + 1];
		resultArray[0] = 0;

		for (int i = 1, j = 0; i <= arr1.length; i++, j++) {
			resultArray[i] = resultArray[i - 1] + arr1[j];
		}
	}

	public String toString() {
		String s = "Sums of prefixes of " + getSeq1String() + " is: " + getResultString();
		return s;
	}

}
