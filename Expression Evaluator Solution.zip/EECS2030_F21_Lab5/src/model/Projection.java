package model;

public class Projection extends BinarySeqOperation {

	private int maxLength;
	private int nov; // no. of values

	public Projection() {
		// just initialize the default values of variables
	}

	public Projection(int[] arr1, int[] arr2) {
		super(arr1, arr2);
		setResult();
	}

	
	public void setResult() {

		// Finding the bigger length among 2 arrays
		if (arr1.length >= arr2.length) {
			maxLength = arr1.length;
		} else {
			maxLength = arr2.length;
		}

		// Projection
		int[] projArrTmp = new int[maxLength];

		for (int i = 0; i < arr2.length; i++) {
			for (int j = 0; j < arr1.length; j++) {
				if (arr2[i] == arr1[j]) {
					projArrTmp[nov] = arr1[j];
					nov++;
					break;

				}
			}
		}

		// Shortening the length by transfer of values
		resultArray = new int[nov];
		for (int i = 0; i < nov; i++) {
			resultArray[i] = projArrTmp[i];
		}
	}

	public String toString() {
		String s = "Projecting " + getSeq1String() + " to " + getSeq2String() + " results in: " + getResultString();
		return s;
	}

}
