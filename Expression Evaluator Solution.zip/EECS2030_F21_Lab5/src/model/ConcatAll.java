package model;

public class ConcatAll extends SeqEvaluator {
	private String seqInputs;

	public ConcatAll() {
		// just initialize the default values of variables
	}

	public ConcatAll(int maxOps) {
		super(maxOps);
		seqInputs = "";
	}

	public String concatArr(String concatenatedString, int[] arr) {
		for (int i = 0; arr != null && i < arr.length; i++) {
			if (concatenatedString != "") {
				concatenatedString += ", ";
			}
			concatenatedString += arr[i];
		}
		return concatenatedString;
	}

	public void addOperation(String operation, int[] seq1, int[] seq2) {
		if (operation.equals("op:projection")) {
			projectedArray[numOfOps] = new Projection(seq1, seq2);
		} else if (operation.equals("op:sumsOfPrefixes")) {
			projectedArray[numOfOps] = new SumsOfPrefixes(seq1);
		} else if (operation.equals("op:occursWithin")) {
			projectedArray[numOfOps] = new OccursWithin(seq1, seq2);
			numOfInvalidOperations++;
		} else {
			throw new IllegalOperationException();
		}
		numOfOps++;
	}

	public String getConcatenatedString() {
		String concatenatedString = "";
		for (int i = 0; i < numOfOps; i++) {
			int[] resultArr = projectedArray[i].getResultArr();
			if (i != 0) {
				seqInputs += ", ";
			}
			seqInputs += convertIntArrayToString(resultArr);
			concatenatedString = concatArr(concatenatedString, resultArr);
		}
		return concatenatedString;
	}

	public String toString() {
		String s;
		if (numOfInvalidOperations > 0) {
			s = "Concat cannot be evaluated due to " + numOfInvalidOperations + " incompatile operations.";
		} else {
			String concatenatedString = getConcatenatedString();
			s = "Concat(" + seqInputs + ") = [" + concatenatedString + "]";
		}
		return s;
	}

	public String convertIntArrayToString(int[] arr) {
		if (arr == null) {
			return "[]";
		}
		String s = "[";
		for (int i = 0; i < arr.length; i++) {
			if ((i != 0)) {
				s += ", ";
			}
			s += arr[i];
		}
		s += "]";
		return s;
	}

}
